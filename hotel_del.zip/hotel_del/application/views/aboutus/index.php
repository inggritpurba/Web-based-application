<!DOCTYPE html>
<html lang="en">
<head>
    <style>
       
    .space {
            text-align: center;
         
            
        }
    </style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div class="container ">
    <h3 class="space">About Us</h3>
            <p>Thank you for your interest in our company: what you are reading right now Is the Company Profile for del Hotels Management & Consultant, a rapidly growing professional hospitality/hotel management company that I am sure you will hear about more often in the future every time you are looking for a good Hotel to stay at.
            To become one of the leading hospitality management companies in Indonesia is our goal, and we realize it is a goal that is impossible to achieve without support. This Company Profile is a part of our effort to introduce ourselves better to our clients, our guests, and you; the people whose support we need the most in order to achieve our goal, the people that matter the most.
            With this Company Profile you can learn about our philosophy, our character, our product/service, our people, and more. Wise men once say that “you only can love what you know”, and thus we hope that our introduction in this Company Profile to you can be a good beginning of a great relationship between our company and you that will last for a long, long time.
            </p>
        <div class="space row mt-3">
            <table border="0" >
                <tr><td > <h3>Mission</h3>
                    <p>•	Developing a positive and highly encouraging working environment where employees can aspire to become the best in whatever they do while acquiring the skills and the aptitude necessary to develop even further.</p> 
                    <p>•	Developing only the best in Hotel and Resort experience where guests and clients are treated not only customers, but as close friend or even a part of family member whose well-being and needs are always a priority in our considerations.</p>
                    <p>•	Developing a mutually beneficial relationship with our shareholders and business partners that are based in trust and the belief that we are a dependable and reliable company that will always strive to deliver the best possible results.</p>
                </td>
                <td > <h3>Vision</h3>
                <p>
                To transform ourselves into a locally based professional hotels & resorts management company with a strong, dependable reputation in the highly competitive Indonesian and even International Hospitality industry.</p>
                <p>           </p>
                <p>            </p></td>
                </tr>
        </table>
    </div>
    </div>
    </div>

    
</body>
</html>

